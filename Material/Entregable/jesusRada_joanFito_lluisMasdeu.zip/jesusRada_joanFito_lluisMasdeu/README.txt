Per executar el joc es pot fer de dues maneres. Obrint el projecte en Unity o obrint l’executable que hem creat.

Obrint el projecte:

- Obrim Unity y carreguem el projecte.
- Si no hi ha cap escena del projecte carregada, carregar la escena anomenada Main Menu.
  (Això es fa arrossegant l’escena desde la finestra d’Assets al sector de la esquerra).
- Donar al botó play.

 * En aquest mode no es pot sortir del joc mitjançant el botó de Exit.

Obrint l’executable:

- Per crear l’executable: File -> Build Settings… -> PC, Mac & Linux Standalone -> Escollim arquitectura -> Desem l’executable.
- Obrim l’executable per a la plataforma corresponent. (Només hem provat la versió de macOS).
- Seleccionem la configuració gràfica.

El segon mètode es el més senzill, pero també és amb el qual tenim menys experiència, doncs els executables els genera el propi Unity.

Funcionament del joc:

- Desplaçament lateral: A i D (o Esquerra i Dreta).
- Saltar: Espai.
- Disparar: Click amb el ratolí.